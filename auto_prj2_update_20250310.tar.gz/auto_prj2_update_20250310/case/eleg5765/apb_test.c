/*
Copyright (c) 2019 Alibaba Group Holding Limited

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/
#include "stdio.h"
#include "datatype.h"
void sim_end()
{
  int END_FLAG;
  END_FLAG = 0x2002;
  *(volatile uint32_t *)  0x20007c50 = END_FLAG;
  *(volatile uint32_t *)  0x20007c50 = END_FLAG;
}


void sim_fail()
{
  int END_FLAG;
  END_FLAG = 0x1001;
  *(volatile uint32_t *)  0x20007c50 = END_FLAG;
  *(volatile uint32_t *)  0x20007c50 = END_FLAG;
}
int main (void)
{
  int read0;
  int read1;
  int read2;
  int read3;
  int err_cnt;
  printf("\nHello Friend! For case:APB TEST0 \n");

    *(volatile uint32_t *) 0x50004000  = 0x10000001;
    *(volatile uint32_t *) 0x50004004  = 0x20000002;
    *(volatile uint32_t *) 0x50004008  = 0x30000003;
    *(volatile uint32_t *) 0x5000400c  = 0x40000004;
    err_cnt =0; 
    read0= *(volatile uint32_t *) 0x50004000;
    if(read0 == 0x10000001){
  	printf("\nread0 test successfully:%x\n",read0);
    }else{
	err_cnt ++;
  	printf("\nread0 test FAIL:%x\n",read0);
    }

    read1= *(volatile uint32_t *) 0x50004004;
    if(read1 == 0x20000002){
  	printf("\nread1 test successfully:%x\n",read1);
    }else{
	err_cnt ++;
  	printf("\nread1 test FAIL:%x\n",read0);
    }

    read2= *(volatile uint32_t *) 0x50004008;
    if(read2 == 0x30000003){
  	printf("\nread2 test successfully:%x\n",read2);
    }else{
	err_cnt ++;
  	printf("\nread2 test FAIL:%x\n",read2);
    }

    read3= *(volatile uint32_t *) 0x5000400c;
    if(read3 == 0x40000004){
  	printf("\nread3 test successfully:%x\n",read3);
    }else{
	err_cnt ++;
  	printf("\nread3 test FAIL:%x\n",read3);
    }

  printf("\nAPB WRITE/READ test Done\n");
  if(err_cnt){
  	printf("\nwrite/read test FAIL NUM:%x\n",err_cnt);
  	sim_fail();
  }
  else{
  	sim_end();
  }
} 



