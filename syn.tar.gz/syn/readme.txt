Prepare:
1)put folder syn at wujian100_open/syn
2)copy library of TSMC.90 at wujian100_open/syn/lib/TSMC.90

Synthesize:
1)cd wujian100_open/syn 
2)./run 
